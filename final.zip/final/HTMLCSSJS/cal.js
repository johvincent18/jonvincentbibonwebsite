function getUserInput() {
    var num1 = parseInt(document.getElementById("number1").value);
    var num2 = parseInt(document.getElementById("number2").value);
    return { num1, num2 }; // return both values in an object
}

function performOperation(operation) {
    const { num1, num2 } = getUserInput(); // destructuring the input values

    let result;
    switch (operation) {
        case 'add':
            result = num1 + num2;
            break;
        case 'subtract':
            result = num1 - num2;
            break;
        case 'multiply':
            result = num1 * num2;
            break;
        case 'divide':
            result = num2 !== 0 ? num1 / num2 : 'Error: Division by zero';
            break;
        case 'modulus':
            result = num1 % num2;
            break;
        default:
            result = 'Invalid operation';
    }

    document.getElementById("result").innerHTML = result; // show the result
    alert("Your answer is: " + result); // show an alert with the result
}