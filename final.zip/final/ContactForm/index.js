const fields = {};


function getGender() {
    const selectedGender = document.querySelector('input[name="gender"]:checked');
    return selectedGender ? selectedGender.value : null;
}


document.addEventListener("DOMContentLoaded", function() {
    fields.firstName = document.getElementById('firstName');
    fields.lastName = document.getElementById('lastName');
    fields.email = document.getElementById('email');
    fields.address = document.getElementById('address');
    fields.houseNumber = document.getElementById('houseNumber');
    fields.country = document.getElementById('country');
    fields.password = document.getElementById('password');
    fields.passwordCheck = document.getElementById('passwordCheck');
    fields.newsletter = document.getElementById('newsletter');
    fields.question = document.getElementById('question');
});

function isNotEmpty(value) {
    return value && value.length > 0;
}

function isNumber(num) {
    return num.length > 0 && !isNaN(num);
}

function isEmail(email) {
    let regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/; 
    return regex.test(String(email).toLowerCase());
}

function isPasswordValid(password) {
    return password.length > 5;
}

function fieldValidation(field, validationFunction) {
    if (field == null) return false;

    let isFieldValid = validationFunction(field.value);
    field.className = isFieldValid ? '' : 'placeholderRed'; 

    return isFieldValid;
}


function isValid() {
    let valid = true;

    valid &= fieldValidation(fields.firstName, isNotEmpty);
    valid &= fieldValidation(fields.lastName, isNotEmpty);
    valid &= fieldValidation(fields.gender, getGender); 
    valid &= fieldValidation(fields.address, isNotEmpty);
    valid &= fieldValidation(fields.country, isNotEmpty);
    valid &= fieldValidation(fields.email, isEmail);
    valid &= fieldValidation(fields.houseNumber, isNumber);
    valid &= fieldValidation(fields.password, isPasswordValid);
    valid &= fieldValidation(fields.passwordCheck, isPasswordValid);
    valid &= fieldValidation(fields.question, isNotEmpty);
    
   
    valid &= arePasswordsEqual();

    return valid;
}


function arePasswordsEqual() {
    const passwordsMatch = fields.password.value === fields.passwordCheck.value;
    
   
    fields.password.className = passwordsMatch ? '' : 'placeholderRed';
    fields.passwordCheck.className = passwordsMatch ? '' : 'placeholderRed';

    return passwordsMatch;
}


class User {
    constructor(firstName, lastName, gender, address, country, email, newsletter, question) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.address = address;
        this.country = country;
        this.email = email;
        this.newsletter = newsletter;
        this.question = question;
    }
}


function sendContact() {
    const genderValue = getGender(); 

    if (isValid()) {
        let usr = new User(
            fields.firstName.value,
            fields.lastName.value,
            genderValue,
            fields.address.value,
            fields.country.value,
            fields.email.value,
            fields.newsletter.checked,
            fields.question.value
        );

        alert(`${usr.firstName}, thanks for registering. Newsletter subscription: ${usr.newsletter}`); 

    } else {
        alert("There was an error in your submission.");
    }
}